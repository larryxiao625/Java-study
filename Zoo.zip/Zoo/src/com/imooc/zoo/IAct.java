package com.imooc.zoo;

public interface IAct {
	String skill();
	String act();
}
